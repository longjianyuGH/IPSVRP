
#include "stdafx.h"

#include <ilcplex/ilocplex.h>
#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <utility>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <math.h>
#include <sstream>
#include <time.h>
using namespace std;
ILOSTLBEGIN

class DepotData
{
public:
	int m_depotID;
	double m_Xposition;
	double m_Yposition;
protected:
private:
};



class Coefficient
{
public:
	double hiring_vehicle;
	double infeasibleCoff;
protected:
private:
};

class CustomerData
{
public:
	int m_customerID;
	double m_Xposition;
	double m_Yposition;
	double m_demand;
	double m_processingTime;
	double m_earliestDuedate;
	double m_latestDuedate;
	double m_unitHoldingCost;
	double m_unitTardinessCost;
protected:
private:
};
class ChromosomeOrg
{
public:
	vector<double> m_chroVec1;//determine the processing sequence of jobs
	vector<double> m_chroVec2;//allocate the vehicle for each job
	vector<double> m_chroVec3;//determine the visiting sequence of jobs
	vector<double> m_chroVec4;//determine the idle time intervals on the machine
	vector<double> m_chroVec5;//determine the idle time between the departure time of each vehicle and the completion time of its last job
protected:
private:
};

class Chromosome
{
public:
	vector<int> m_chroVec1;//determine the processing sequence of jobs
	vector<int> m_chroVec2;//allocate the vehicle for each job
	vector<int> m_chroVec3;//determine the visiting sequence of jobs
	vector<double> m_chroVec4;//determine the idle time intervals on the machine
	vector<double> m_chroVec5;//determine the idle time between the departure time of each vehicle and the completion time of its last job
protected:
private:
};
class ChromosomeVelocity
{
public:
	vector<double> m_VelchroVec1;//determine the processing sequence of jobs
	vector<double> m_VelchroVec2;//allocate the vehicle for each job
	vector<double> m_VelchroVec3;//determine the visiting sequence of jobs
	vector<double> m_VelchroVec4;//determine the idle time intervals on the machine
	vector<double> m_VelchroVec5;//determine the idle time between the departure time of each vehicle and the completion time of its last job
protected:
private:
};
class SolutionObj
{
public:
	bool m_feasible;
	double m_overLoad;
	double m_obj1;
	double m_obj2;
	double m_obj3;
protected:
private:
};
class SolutionInformation
{
public:
	map<int,double> vechicleDepartTime;
	map<int,double> jobCompleteTime;
	vector<int> LastProcessingJob;
	vector<pair<int,double>> allJobTardyVec;
protected:
private:
};
class ChromosomeEvaluation
{
public:
	
protected:
private:
};
class IDMultiObjValue
{
public:
	int m_layerIndexID;
	double m_obj1;//total holding cost
	double m_obj2;//total traveling cost
	double m_obj3;//total tardiness costs
protected:
private:
};
class FindSolutionObj2
{
public:
	FindSolutionObj2(SolutionObj sss) : m_sss(sss) {}
	bool operator() (const SolutionObj &s)
	{
		double sobj1=floor(s.m_obj1*10000.000f+0.5)/10000.000f;
		double msobj1=floor(m_sss.m_obj1*10000.000f+0.5)/10000.000f;
		double sobj2=floor(s.m_obj2*10000.000f+0.5)/10000.000f;
		double msobj2=floor(m_sss.m_obj2*10000.000f+0.5)/10000.000f;
		double sobj3=floor(s.m_obj3*10000.000f+0.5)/10000.000f;
		double msobj3=floor(m_sss.m_obj3*10000.000f+0.5)/10000.000f;
		if (sobj1==msobj1 && sobj2==msobj2 && sobj3==msobj3)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
protected:
private:
	SolutionObj m_sss;
};

class LSParticleInfoForSort
{
public:
	SolutionObj individualObj;
	int solutionIndex;
	int flag;
	double cdDistance;
	LSParticleInfoForSort()
	{
		cdDistance=0.0;
	}
protected:
private:
};

class LSParticleInfo
{
public:
	ChromosomeOrg populationOrg;
	Chromosome population;
	ChromosomeVelocity populationVelocity;
	SolutionObj individualObj;
	SolutionInformation individualSolution;
protected:
private:
};

class FindSolutionObj
{
public:
	FindSolutionObj(SolutionObj sss) : m_sss(sss) {}
	bool operator() (const LSParticleInfoForSort &s)
	{
		double sobj1=floor(s.individualObj.m_obj1*10000.000f+0.5)/10000.000f;
		double msobj1=floor(m_sss.m_obj1*10000.000f+0.5)/10000.000f;
		double sobj2=floor(s.individualObj.m_obj2*10000.000f+0.5)/10000.000f;
		double msobj2=floor(m_sss.m_obj2*10000.000f+0.5)/10000.000f;
		double sobj3=floor(s.individualObj.m_obj3*10000.000f+0.5)/10000.000f;
		double msobj3=floor(m_sss.m_obj3*10000.000f+0.5)/10000.000f;
		if (sobj1==msobj1 && sobj2==msobj2 && sobj3==msobj3)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
protected:
private:
	SolutionObj m_sss;
};

bool IsPrShort(const pair<double,int> &s1,const pair<double,int> &s2)
{
	return s1.first<s2.first;
}
bool IsObj1Short(const IDMultiObjValue &s1,const IDMultiObjValue &s2)
{
	return s1.m_obj1<s2.m_obj1;
}
bool IsObj2Short(const IDMultiObjValue &s1,const IDMultiObjValue &s2)
{
	return s1.m_obj2<s2.m_obj2;
}
bool IsObj3Short(const IDMultiObjValue &s1,const IDMultiObjValue &s2)
{
	return s1.m_obj3<s2.m_obj3;
}
bool IsCDShort(const LSParticleInfoForSort &s1,const LSParticleInfoForSort &s2)
{
	return s1.cdDistance>s2.cdDistance;
}
bool IsObj1Short_1(const SolutionObj &s1,const SolutionObj &s2)
{
	return s1.m_obj1<s2.m_obj1;
}
bool IsObj2Short_1(const SolutionObj &s1,const SolutionObj &s2)
{
	return s1.m_obj2<s2.m_obj2;
}
bool IsObj3Short_1(const SolutionObj &s1,const SolutionObj &s2)
{
	return s1.m_obj3<s2.m_obj3;
}
bool IsDemandShort(const CustomerData &s1,const CustomerData &s2)
{
	return s1.m_demand>s2.m_demand;
}

bool ReadData(int &vehicleNum,double &vehicleLoad,DepotData &depot,vector<CustomerData> &customerDataVec,string inputFileName)
{
	ifstream myFile(inputFileName);
	myFile>>vehicleNum;
	myFile>>vehicleLoad;
	myFile>>depot.m_depotID;
	myFile>>depot.m_Xposition;
	myFile>>depot.m_Yposition;
	int dac;
	while (myFile>>dac)
	{
		CustomerData cd;
		cd.m_customerID=dac;
		myFile>>cd.m_Xposition;
		myFile>>cd.m_Yposition;
		myFile>>cd.m_demand;
		myFile>>cd.m_processingTime;
		myFile>>cd.m_earliestDuedate;
		myFile>>cd.m_latestDuedate;
		myFile>>cd.m_unitHoldingCost;
		myFile>>cd.m_unitTardinessCost;
		customerDataVec.push_back(cd);
	}
	return true;
}
void Caldistance(map<pair<int,int>,double> &distanceMap,DepotData depot,vector<CustomerData> customerDataVec)
{
	for (int i=0;i<customerDataVec.size();++i)
	{
		pair<int,int> pr1,pr2;
		pr1.first=depot.m_depotID;
		pr1.second=customerDataVec[i].m_customerID;
		pr2.first=customerDataVec[i].m_customerID;
		pr2.second=depot.m_depotID;
		double dis=sqrt((depot.m_Xposition-customerDataVec[i].m_Xposition)*(depot.m_Xposition-customerDataVec[i].m_Xposition)+(depot.m_Yposition-customerDataVec[i].m_Yposition)*(depot.m_Yposition-customerDataVec[i].m_Yposition));
		distanceMap.insert(make_pair(pr1,dis));
		distanceMap.insert(make_pair(pr2,dis));
	}
	
	for (int i=0;i<customerDataVec.size();++i)
	{
		for (int j=i+1;j<customerDataVec.size();++j)
		{
			pair<int,int> pr1,pr2;
			pr1.first=customerDataVec[i].m_customerID;
			pr1.second=customerDataVec[j].m_customerID;
			pr2.first=customerDataVec[j].m_customerID;
			pr2.second=customerDataVec[i].m_customerID;
			double dis=sqrt((customerDataVec[i].m_Xposition-customerDataVec[j].m_Xposition)*(customerDataVec[i].m_Xposition-customerDataVec[j].m_Xposition)+(customerDataVec[i].m_Yposition-customerDataVec[j].m_Yposition)*(customerDataVec[i].m_Yposition-customerDataVec[j].m_Yposition));
			distanceMap.insert(make_pair(pr1,dis));
			distanceMap.insert(make_pair(pr2,dis));
		}
	}
}
void VechicleVisitingSequence(vector<int> v1,vector<int> v2,vector<int> v3,map<int,vector<int>> &vechicleVisitSeq,vector<int> &LastProcessingJob,map<int,int> &vechicleLasProcessingJob)
{
	for (int i=0;i<v3.size();++i)
	{
		int customID=v3[i];
		int vechicleID=v2[customID-1];
		if (vechicleVisitSeq.count(vechicleID))
		{
			vechicleVisitSeq[vechicleID].push_back(customID);
		}
		else
		{
			vector<int> tt;
			tt.push_back(customID);
			vechicleVisitSeq.insert(make_pair(vechicleID,tt));
		}
	}

	vector<int> pjTemp;
	for (map<int,vector<int>>::iterator mit=vechicleVisitSeq.begin();mit!=vechicleVisitSeq.end();++mit)
	{
		vector<int> temp=mit->second;
		if (temp.size()==1)
		{
			vechicleLasProcessingJob.insert(make_pair(mit->first,temp[0]));
			pjTemp.push_back(temp[0]);
		}
		else
		{
			for (int i=0;i<v1.size();++i)
			{
				if (count(temp.begin(),temp.end(),v1[i]))
				{
					temp.erase(find(temp.begin(),temp.end(),v1[i]));
				}
				if (temp.size()==1)
				{
					vechicleLasProcessingJob.insert(make_pair(mit->first,temp[0]));
					pjTemp.push_back(temp[0]);
					break;
				}
			}
		}
	}
	for (int i=0;i<v1.size();++i)
	{
		if (count(pjTemp.begin(),pjTemp.end(),v1[i]))
		{
			LastProcessingJob.push_back(v1[i]);
		}
	}

}
void ChangeFromPop(Chromosome &Chro,ChromosomeOrg &ChroOrg,int vehicleNum)
{
	Chro.m_chroVec1=vector<int>(ChroOrg.m_chroVec1.size(),0);
	Chro.m_chroVec2=vector<int>(ChroOrg.m_chroVec2.size(),0);
	Chro.m_chroVec3=vector<int>(ChroOrg.m_chroVec3.size(),0);
	Chro.m_chroVec4=ChroOrg.m_chroVec4;
	Chro.m_chroVec5=ChroOrg.m_chroVec5;

	vector<pair<double,int>> svpair1;
	vector<pair<double,int>> svpair3;
	for (int i=0;i<ChroOrg.m_chroVec1.size();++i)
	{
		pair<double,int> pr1,pr3;
		pr1.first=ChroOrg.m_chroVec1[i];
		pr1.second=i+1;
		pr3.first=ChroOrg.m_chroVec3[i];
		pr3.second=i+1;
		svpair1.push_back(pr1);
		svpair3.push_back(pr3);
	}
	sort(svpair1.begin(),svpair1.end(),IsPrShort);
	sort(svpair3.begin(),svpair3.end(),IsPrShort);
	for (int i=0;i<svpair1.size();++i)
	{
		Chro.m_chroVec1[i]=svpair1[i].second;
		Chro.m_chroVec3[i]=svpair3[i].second;
	}

	for (int i=0;i<ChroOrg.m_chroVec2.size();++i)
	{
		int dv=(int)(ChroOrg.m_chroVec2[i]+0.5);
		if (dv<1)
		{
			dv=1;
		}
		else if (dv>vehicleNum)
		{
			dv=vehicleNum;
		}
		Chro.m_chroVec2[i]=dv;
	}
	//
	for (int i=0;i<Chro.m_chroVec4.size();++i)
	{
		if (Chro.m_chroVec4[i]<0)
		{
			Chro.m_chroVec4[i]=0;
		}
		if (Chro.m_chroVec5[i]<0)
		{
			Chro.m_chroVec5[i]=0;
		}
	}
}
void ChangeFromPopOrg(vector<Chromosome> &population,vector<ChromosomeOrg> &populationOrg)
{
	
	for (vector<Chromosome>::iterator pit=population.begin();pit!=population.end();++pit)
	{
		ChromosomeOrg chroOrg;
		chroOrg.m_chroVec1=vector<double>(pit->m_chroVec1.size(),0.0);
		chroOrg.m_chroVec2=vector<double>(pit->m_chroVec2.size(),0.0);
		chroOrg.m_chroVec3=vector<double>(pit->m_chroVec3.size(),0.0);
		chroOrg.m_chroVec4=pit->m_chroVec4;
		chroOrg.m_chroVec5=pit->m_chroVec5;
		int startNum=0;
		for (vector<int>::iterator it=pit->m_chroVec1.begin();it!=pit->m_chroVec1.end();++it)
		{
			int indexOrg=*it-1;
			double val=(startNum*100+rand()%101)/100.0;
			chroOrg.m_chroVec1[indexOrg]=val;
			++startNum;
		}
		int v2Index=0;
		for (vector<int>::iterator it=pit->m_chroVec2.begin();it!=pit->m_chroVec2.end();++it)
		{
			int val=*it;
			double minV=val-0.5;
			double maxV=val+0.4;
			double dval=((int)(minV*100)+rand()%(int)(maxV*100-minV*100+1))/100.0;
			chroOrg.m_chroVec2[v2Index]=dval;
			++v2Index;
		}
		startNum=0;
		for (vector<int>::iterator it=pit->m_chroVec3.begin();it!=pit->m_chroVec3.end();++it)
		{
			int indexOrg=*it-1;
			double val=(startNum*100+rand()%101)/100.0;
			chroOrg.m_chroVec3[indexOrg]=val;
			++startNum;
		}
		populationOrg.push_back(chroOrg);
	}
	
}
void PopIni(vector<Chromosome> &population,vector<ChromosomeVelocity> &populationVelocity,int vehicleNum,int customerNum,int popSize,double vehicleLoad,vector<CustomerData> &customerDataVec,map<pair<int,int>,double> &distanceMap)
{
	for (int psn=1;psn<=popSize;++psn)
	{
		map<int,double> vechicleCapacity;
		for (int v=1;v<=vehicleNum;++v)
		{
			vechicleCapacity.insert(make_pair(v,vehicleLoad));
		}

		
		vector<CustomerData> cdTemp=customerDataVec;
		sort(cdTemp.begin(),cdTemp.end(),IsDemandShort);
		
		vector<int> v1;
		vector<int> v2(customerNum,0);
		vector<int> v3;
		for (int i=1;i<=customerNum;++i)
		{
			v1.push_back(i);
			v3.push_back(i);
			int randV=1+rand()%vehicleNum;
			while (cdTemp[i-1].m_demand>=vechicleCapacity[randV])
			{
				randV=1+rand()%vehicleNum;
			}
			//v2.push_back(randV);
			v2[cdTemp[i-1].m_customerID-1]=randV;
			vechicleCapacity[randV]-=cdTemp[i-1].m_demand;
		}
		random_shuffle(v1.begin(),v1.end());
		random_shuffle(v3.begin(),v3.end());
		

		vector<double> v4;
		vector<double> v5;
		map<int,vector<int>> vechicleVisitSeq;
		vector<int> LastProcessingJob;
		map<int,int> vechicleLasProcessingJob;
		VechicleVisitingSequence(v1,v2,v3,vechicleVisitSeq,LastProcessingJob,vechicleLasProcessingJob);

		map<int,double> jobHardTime;
		map<int,double> vechicleHardTime;
		double vt=0;
		for (vector<int>::iterator it=v1.begin();it!=v1.end();++it)
		{
			vt+=customerDataVec[*it-1].m_processingTime;//
			for (map<int,int>::iterator mit=vechicleLasProcessingJob.begin();mit!=vechicleLasProcessingJob.end();++mit)
			{
				if (mit->second==*it)
				{
					vechicleHardTime.insert(make_pair(mit->first,vt));
					break;
				}
			}
		}
		for (vector<int>::iterator it=v1.begin();it!=v1.end();++it)
		{
			int vechicleNum=v2[*it-1];
			double ht=vechicleHardTime[vechicleNum];


			pair<int,int> jobPair;
			jobPair.first=0;
			for (vector<int>::iterator vsit=vechicleVisitSeq[vechicleNum].begin();vsit!=vechicleVisitSeq[vechicleNum].end();++vsit)
			{
				jobPair.second=*vsit;
				ht+=distanceMap[jobPair];
				if (*vsit==*it)
				{
					break;
				}
				jobPair.first=*vsit;
			}
			jobHardTime.insert(make_pair(*it,ht));
		}
		int realUsedVehicleNum=vechicleVisitSeq.size();
		for (int u=1;u<=realUsedVehicleNum;++u)
		{
			vector<int> jobAfterIdleu;
			if (u==1)
			{
				jobAfterIdleu=v1;
			}
			else
			{
				vector<int> tt(find(v1.begin(),v1.end(),LastProcessingJob[u-2])+1,v1.end());
				jobAfterIdleu=tt;
			}
			
			double TUBu=0;
			for (int ji=0;ji<jobAfterIdleu.size();++ji)
			{
				
				double TUBiu=accumulate(v4.begin(),v4.end(),0)+jobHardTime[jobAfterIdleu[ji]];
				TUBiu=customerDataVec[jobAfterIdleu[ji]-1].m_latestDuedate-TUBiu;
				if (TUBu==0)
				{
					TUBu=TUBiu;
				}
				else
				{
					if (TUBiu>TUBu)
					{
						TUBu=TUBiu;
					}
				}

			}

			int bound;
			if (TUBu>0)
			{
				bound=TUBu+1;
				v4.push_back(0+rand()%(bound+1));
			} 
			else
			{
				v4.push_back((rand()%11)/10.0);
			}

		}
		for (int i=realUsedVehicleNum+1;i<=vehicleNum;++i)
		{
			v4.push_back((rand()%11)/10.0);
		}

		for (int i=1;i<=vehicleNum;++i)
		{
			v5.push_back((rand()%11)/10.0);
		}
		for (map<int,vector<int>>::iterator vit=vechicleVisitSeq.begin();vit!=vechicleVisitSeq.end();++vit)
		{

			double TUBu=0;
			vector<int> jobAfterIdleu=vit->second;
			for (int ji=0;ji<jobAfterIdleu.size();++ji)
			{
				double TUBiu=jobHardTime[jobAfterIdleu[ji]];
				TUBiu=customerDataVec[jobAfterIdleu[ji]-1].m_latestDuedate-TUBiu;
				if (TUBu==0)
				{
					TUBu=TUBiu;
				}
				else
				{
					if (TUBiu>TUBu)
					{
						TUBu=TUBiu;
					}
				}
			}

			int bound;
			if (TUBu>0)
			{
				bound=TUBu+1;
				v5[vit->first-1]=rand()%(bound+1);
			} 
			else
			{
				v5[vit->first-1]=(rand()%11)/10.0;
			}
		}

		Chromosome cs;
		cs.m_chroVec1=v1;
		cs.m_chroVec2=v2;
		cs.m_chroVec3=v3;
		cs.m_chroVec4=v4;
		cs.m_chroVec5=v5;

		population.push_back(cs);
	}
	
	for (vector<Chromosome>::iterator pit=population.begin();pit!=population.end();++pit)
	{
		vector<double> v1(pit->m_chroVec1.size(),0);
		vector<double> v2(pit->m_chroVec2.size(),0);
		vector<double> v3(pit->m_chroVec3.size(),0);
		vector<double> v4(pit->m_chroVec4.size(),0);
		vector<double> v5(pit->m_chroVec5.size(),0);
		ChromosomeVelocity cv;
		cv.m_VelchroVec1=v1;
		cv.m_VelchroVec2=v2;
		cv.m_VelchroVec3=v3;
		cv.m_VelchroVec4=v4;
		cv.m_VelchroVec5=v5;
		populationVelocity.push_back(cv);
	}
}

void DecodeChromosome(Chromosome &chrom,SolutionObj &sobj,vector<CustomerData> &customerDataVec,map<pair<int,int>,double> &distanceMap,double vehicleLoad,Coefficient &modelCoeff,SolutionInformation &solInf)
{
	map<int,vector<int>> vechicleVisitSeq;
	vector<int> LastProcessingJob;
	map<int,int> vechicleLasProcessingJob;
	VechicleVisitingSequence(chrom.m_chroVec1,chrom.m_chroVec2,chrom.m_chroVec3,vechicleVisitSeq,LastProcessingJob,vechicleLasProcessingJob);
	
	map<int,double> vechicleDepartTime;
	map<int,double> jobCompleteTime;
	double lastSumTime=0;
	int lastCalIndex=0;
	//int idleTimeIndex=0;
	for (vector<int>::iterator lastJobit=LastProcessingJob.begin();lastJobit!=LastProcessingJob.end();++lastJobit)
	{
		
		double idleTime=0;
		if (lastJobit==LastProcessingJob.begin())
		{
			int vid=chrom.m_chroVec2[chrom.m_chroVec1.back()-1];
			idleTime=chrom.m_chroVec4[vid-1];
		} 
		else
		{
			vector<int>::iterator lj=lastJobit-1;
			int vid=chrom.m_chroVec2[*lj-1];
			idleTime=chrom.m_chroVec4[vid-1];
		}
		lastSumTime+=idleTime;
		for (int i=lastCalIndex;i<chrom.m_chroVec1.size();++i)
		{
			lastSumTime+=customerDataVec[chrom.m_chroVec1[i]-1].m_processingTime;
			jobCompleteTime.insert(make_pair(chrom.m_chroVec1[i],lastSumTime));
			++lastCalIndex;
			if (*lastJobit==chrom.m_chroVec1[i])
			{
				int vechicleNum=chrom.m_chroVec2[chrom.m_chroVec1[i]-1];
				double idleTimeBeforeDep=chrom.m_chroVec5[vechicleNum-1];
				vechicleDepartTime.insert(make_pair(vechicleNum,lastSumTime+idleTimeBeforeDep));
				break;
			} 
		}
	}

	map<int,double> jobDeliverTime;
	double totalTardinessPenalty=0;
	map<int,double> vechicleTotalLoad;
	vector<pair<int,double>> allJobTardyVec;
	for (map<int,vector<int>>::iterator mit=vechicleVisitSeq.begin();mit!=vechicleVisitSeq.end();++mit)
	{
		double totalLoad=0;
		double iniTime=vechicleDepartTime[mit->first];
		pair<int,int> idPair;
		idPair.first=0;
		bool isTardyFlag=true;
		double minAdvancedTime=DBL_MAX;
		for (vector<int>::iterator it=mit->second.begin();it!=mit->second.end();++it)
		{
			totalLoad+=customerDataVec[*it-1].m_demand;
			idPair.second=*it;
			double transTime=distanceMap[idPair];
			double temp=iniTime+transTime;
			if (temp<customerDataVec[*it-1].m_earliestDuedate)
			{
				iniTime=customerDataVec[*it-1].m_earliestDuedate;
				jobDeliverTime.insert(make_pair(*it,iniTime));
				isTardyFlag=false;
			} 
			else if(temp>=customerDataVec[*it-1].m_earliestDuedate && temp<=customerDataVec[*it-1].m_latestDuedate)
			{
				iniTime=temp;
				jobDeliverTime.insert(make_pair(*it,iniTime));
				double subTime=iniTime-customerDataVec[*it-1].m_earliestDuedate;
				if (subTime<minAdvancedTime)
				{
					minAdvancedTime=subTime;
				}
			}
			else
			{
				iniTime=temp;
				jobDeliverTime.insert(make_pair(*it,iniTime));
				double subTime=iniTime-customerDataVec[*it-1].m_earliestDuedate;
				if (subTime<minAdvancedTime)
				{
					minAdvancedTime=subTime;
				}
				double totalTardinessTime=temp-customerDataVec[*it-1].m_latestDuedate;
				totalTardinessPenalty+=customerDataVec[*it-1].m_unitTardinessCost*totalTardinessTime;
			}
			idPair.first=*it;
		}
		vechicleTotalLoad.insert(make_pair(mit->first,totalLoad));
		if (isTardyFlag)
		{
			pair<int,double> pr;
			pr.first=mit->first;
			pr.second=minAdvancedTime;
			allJobTardyVec.push_back(pr);
		}
	}

	sobj.m_overLoad=0;
	sobj.m_feasible=true;
	for (map<int,double>::iterator vit=vechicleTotalLoad.begin();vit!=vechicleTotalLoad.end();++vit)
	{
		if (vit->second>vehicleLoad)
		{
			sobj.m_feasible=false;
			sobj.m_overLoad+=vit->second-vehicleLoad;
		}
	}
	
	double holdTimePenalty=0;
	for (map<int,double>::iterator mit=jobCompleteTime.begin();mit!=jobCompleteTime.end();++mit)
	{
		int vechicleID=chrom.m_chroVec2[mit->first-1];
		double departTime=vechicleDepartTime[vechicleID];
		double holdTime=departTime-mit->second;
		holdTimePenalty+=customerDataVec[mit->first-1].m_unitHoldingCost*holdTime;
	}
	sobj.m_obj1=holdTimePenalty;
	if (holdTimePenalty<0)
	{
		int k=0;
	}
	
	sobj.m_obj2=0;
	for (map<int,vector<int>>::iterator mit=vechicleVisitSeq.begin();mit!=vechicleVisitSeq.end();++mit)
	{
		int lastJob=mit->second.back();
		double deliverTime=jobDeliverTime[lastJob];
		pair<int,int> idPair;
		idPair.first=lastJob;
		idPair.second=0;
		double transTime=distanceMap[idPair];
		double totalTransTime=deliverTime+transTime-vechicleDepartTime[mit->first];
		sobj.m_obj2+=totalTransTime+modelCoeff.hiring_vehicle;
	}

	sobj.m_obj3=totalTardinessPenalty;

	if (sobj.m_feasible==false)
	{
		double addPenalty=modelCoeff.infeasibleCoff*sobj.m_overLoad;
		sobj.m_obj1+=addPenalty;
		sobj.m_obj2+=addPenalty;
		sobj.m_obj3+=addPenalty;
	}

	solInf.jobCompleteTime=jobCompleteTime;
	solInf.vechicleDepartTime=vechicleDepartTime;
	solInf.LastProcessingJob=LastProcessingJob;
	solInf.allJobTardyVec=allJobTardyVec;
}
void CalChromosomeObj(map<int,vector<int>> &solution,SolutionObj &solobj,vector<CustomerData> &customerDataVec,map<pair<int,int>,double> &distanceMap,double vehicleLoad,double minLoad,double infeasiblePenatlyOb1,double infeasiblePenatlyOb2)
{
	
}
void InsertCustomer(vector<int> &vechicle,map<pair<int,int>,double> &distanceMap,int insertCustomerID,double &disIncrease)
{
	
}
void ReverseChangeTwoJobs(int reverseStartIndex,vector<int> &processingSequence,vector<double> &processingSequenceOrg,double &reducedHoldCost,SolutionInformation &solInf,vector<CustomerData> &customerDataVec,Chromosome &chrom)
{
	if (reverseStartIndex==0)
	{
		return;
	}
	int i=reverseStartIndex-1;
	int j=reverseStartIndex;
	int iVid=chrom.m_chroVec2[processingSequence[i]-1];
	int jVid=chrom.m_chroVec2[processingSequence[j]-1];
	if (iVid!=jVid)
	{
		return;
	}
	else
	{
		double aipj=customerDataVec[processingSequence[i]-1].m_unitHoldingCost*customerDataVec[processingSequence[j]-1].m_processingTime;
		double ajpi=customerDataVec[processingSequence[j]-1].m_unitHoldingCost*customerDataVec[processingSequence[i]-1].m_processingTime;
		if (aipj<=ajpi)
		{
			return;
		}
		else
		{
			double startTime=solInf.jobCompleteTime[processingSequence[i]]-customerDataVec[processingSequence[i]-1].m_processingTime;//�����޸ĵ��깤ʱ����
			double orgIProcessingTime=customerDataVec[processingSequence[i]-1].m_processingTime;
			double orgJprocessingTime=customerDataVec[processingSequence[j]-1].m_processingTime;
			int jobI=processingSequence[i];
			int jobJ=processingSequence[j];
			
			int temp=processingSequence[i];
			processingSequence[i]=processingSequence[j];
			processingSequence[j]=temp;
			double tempOrg=processingSequenceOrg[i];
			processingSequenceOrg[i]=processingSequenceOrg[j];
			processingSequenceOrg[j]=tempOrg;
			
			reducedHoldCost+=aipj-ajpi;
			
			solInf.jobCompleteTime[jobJ]=startTime+orgJprocessingTime;
			solInf.jobCompleteTime[jobI]=solInf.jobCompleteTime[jobJ]+orgIProcessingTime;
			ReverseChangeTwoJobs(i,processingSequence,processingSequenceOrg,reducedHoldCost,solInf,customerDataVec,chrom);
		}
	}

}
void NondominatedLocalSearch(vector<LSParticleInfo> &firstFrontChroSol,vector<LSParticleInfo> &improvedFrontChroSol,int Nmax,int Niter,vector<CustomerData> &customerDataVec,double vehicleLoad,int vehicleNum,map<pair<int,int>,double> &distanceMap,Coefficient &modelCoeff)
{
	vector<LSParticleInfo> neighborhoodChroSolVec;
	for (vector<LSParticleInfo>::iterator it=firstFrontChroSol.begin();it!=firstFrontChroSol.end();++it)
	{
		LSParticleInfo currentParticle=*it;
		
		map<int,vector<int>> vechicleJobID;
		map<int,double> vechicleLoadMap;
		for (int index=0;index<it->population.m_chroVec2.size();++index)
		{
			int vechicleID=it->population.m_chroVec2[index];
			if (vechicleLoadMap.count(vechicleID))
			{
				vechicleJobID[vechicleID].push_back(index);
				vechicleLoadMap[vechicleID]+=customerDataVec[index].m_demand;
			}
			else
			{
				vector<int> temp;
				temp.push_back(index);
				vechicleJobID.insert(make_pair(vechicleID,temp));
				vechicleLoadMap.insert(make_pair(vechicleID,customerDataVec[index].m_demand));
			}
		}
		if (it->individualObj.m_feasible==0)
		{
			vector<int> removeJobIDVec;
			map<int,double> vechicleLoadMapTemp=vechicleLoadMap;
			for (map<int,double>::iterator mit=vechicleLoadMapTemp.begin();mit!=vechicleLoadMapTemp.end();++mit)
			{
				double vl=mit->second;
				while (vl>vehicleLoad)
				{
					removeJobIDVec.push_back(vechicleJobID[mit->first].back());
					vl-=customerDataVec[vechicleJobID[mit->first].back()].m_demand;
					vechicleJobID[mit->first].pop_back();
				}
				vechicleLoadMap[mit->first]=vl;
			}

			map<int,int> jobVecIDMap;
			vector<int> stillRemoveJobIDVec;
			for (int jobIndex=0;jobIndex<removeJobIDVec.size();++jobIndex)
			{
				bool isInsert=false;
				for (map<int,double>::iterator mit=vechicleLoadMap.begin();mit!=vechicleLoadMap.end();++mit)
				{
					if (mit->second+customerDataVec[removeJobIDVec[jobIndex]].m_demand <= vehicleLoad)
					{
						jobVecIDMap.insert(make_pair(removeJobIDVec[jobIndex],mit->first));
						vechicleJobID[mit->first].push_back(removeJobIDVec[jobIndex]);
						isInsert=true;
						mit->second+=customerDataVec[removeJobIDVec[jobIndex]].m_demand;
						break;
					}
				}
				if (isInsert==false)
				{
					stillRemoveJobIDVec.push_back(removeJobIDVec[jobIndex]);
				}
			}

			bool isFaileFlag=false;
			while (!stillRemoveJobIDVec.empty())
			{
				if (vechicleJobID.size()==vehicleNum)
				{
					isFaileFlag=true;
					break;
				}
				
				int allowVi;
				for (int vi=1;vi<=vehicleNum;++vi)
				{
					if (!vechicleJobID.count(vi))
					{
						allowVi=vi;
						break;
					}
				}
				
				vector<int> stillRemoveJobIDVecTemp=stillRemoveJobIDVec;
				double sumLoad=0;
				int deleteIndex=0;
				vector<int> iIdexVec;
				for (int i=0;i<stillRemoveJobIDVecTemp.size();++i)
				{
					if (customerDataVec[stillRemoveJobIDVecTemp[i]].m_demand+sumLoad <= vehicleLoad)
					{
						jobVecIDMap.insert(make_pair(stillRemoveJobIDVecTemp[i],allowVi));
						iIdexVec.push_back(stillRemoveJobIDVecTemp[i]);
						sumLoad+=customerDataVec[stillRemoveJobIDVecTemp[i]].m_demand;
						stillRemoveJobIDVec.erase(stillRemoveJobIDVec.begin()+(i-deleteIndex));
						++deleteIndex;
					}
				}
				vechicleJobID.insert(make_pair(allowVi,iIdexVec));
			}
			if (isFaileFlag==false)
			{
				
				LSParticleInfo feasibleParticle=currentParticle;
				for (int chroIndex=0;chroIndex<feasibleParticle.population.m_chroVec2.size();++chroIndex)
				{
					if (jobVecIDMap.count(chroIndex))
					{
						feasibleParticle.population.m_chroVec2[chroIndex]=int(jobVecIDMap[chroIndex]);
						feasibleParticle.populationOrg.m_chroVec2[chroIndex]=double(jobVecIDMap[chroIndex]);
					}
				}
				
				SolutionObj obj;
				SolutionInformation solInf;
				DecodeChromosome(feasibleParticle.population,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
				feasibleParticle.individualObj=obj;
				feasibleParticle.individualSolution=solInf;
				
				neighborhoodChroSolVec.push_back(feasibleParticle);
				currentParticle=feasibleParticle;
			}
			else
			{
				continue;
			}
		}
		
		LSParticleInfo currentParticleTemp=currentParticle;

		vector<int> vechicleSeq;
		for (int jobIndex=0;jobIndex<currentParticle.population.m_chroVec1.size();++jobIndex)
		{
			int jid=currentParticle.population.m_chroVec1[jobIndex];
			int vid=currentParticle.population.m_chroVec2[jid-1];
			if (count(vechicleSeq.begin(),vechicleSeq.end(),vid)==0)
			{
				vechicleSeq.push_back(vid);
			}
		}

		vector<int> newJobProcessSqe;
		for (vector<int>::iterator it=vechicleSeq.begin();it!=vechicleSeq.end();++it)
		{
			vector<int> newJobProcessSqeInThisVec;
			vector<int> jobProcessSqeInThisVec=vechicleJobID[*it];
			double sumProcessingTime=0;
			for (vector<int>::iterator jit=jobProcessSqeInThisVec.begin();jit!=jobProcessSqeInThisVec.end();++jit)
			{
				sumProcessingTime+=customerDataVec[*jit].m_processingTime;
			}
			while (sumProcessingTime>0)
			{
				double minValue=-1;
				int minJobIndex;
				for (int ji=0;ji<jobProcessSqeInThisVec.size();++ji)
				{
					double tt=(sumProcessingTime-customerDataVec[jobProcessSqeInThisVec[ji]].m_processingTime)*customerDataVec[jobProcessSqeInThisVec[ji]].m_unitHoldingCost;
					if (minValue==-1)
					{
						minValue=tt;
						minJobIndex=ji;
					}
					else
					{
						if (minValue > tt)
						{
							minValue=tt;
							minJobIndex=ji;
						}
					}
				}
				newJobProcessSqeInThisVec.push_back(jobProcessSqeInThisVec[minJobIndex]+1);
				sumProcessingTime-=customerDataVec[jobProcessSqeInThisVec[minJobIndex]].m_processingTime;
				jobProcessSqeInThisVec.erase(jobProcessSqeInThisVec.begin()+minJobIndex);
			}
			newJobProcessSqe.insert(newJobProcessSqe.end(),newJobProcessSqeInThisVec.begin(),newJobProcessSqeInThisVec.end());
		}
		currentParticle.population.m_chroVec1=newJobProcessSqe;
		vector<double> orgv1=currentParticle.populationOrg.m_chroVec1;
		sort(orgv1.begin(),orgv1.end());
		for (int v1idex=0;v1idex<currentParticle.population.m_chroVec1.size();++v1idex)
		{
			currentParticle.populationOrg.m_chroVec1[currentParticle.population.m_chroVec1[v1idex]-1]=orgv1[v1idex];
		}
		
		int lastJobID=currentParticle.population.m_chroVec1.back();
		int lastVechicleID=currentParticle.population.m_chroVec2[lastJobID-1];
		for (int v4idex=0;v4idex<currentParticle.population.m_chroVec4.size();++v4idex)
		{
			if (v4idex!=lastVechicleID-1)
			{
				currentParticle.population.m_chroVec4[v4idex]=0;
				currentParticle.populationOrg.m_chroVec4[v4idex]=0;
			}
			currentParticle.population.m_chroVec5[v4idex]=0;
			currentParticle.populationOrg.m_chroVec5[v4idex]=0;
		}

		SolutionObj obj;
		SolutionInformation solInf;
		DecodeChromosome(currentParticle.population,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
		currentParticle.individualObj=obj;
		currentParticle.individualSolution=solInf;

		neighborhoodChroSolVec.push_back(currentParticle);
		
		for (map<int,vector<int>>::iterator mit=vechicleJobID.begin();mit!=vechicleJobID.end();++mit)
		{
			for (int i=0;i<mit->second.size()-1;++i)
			{
				for (int j=i+1;j<mit->second.size();++j)
				{
					currentParticle=currentParticleTemp;

					vector<int> jobset=mit->second;
					int iJob=jobset[i];
					int jJob=jobset[j];
					double dtemp=currentParticle.populationOrg.m_chroVec3[iJob];
					currentParticle.populationOrg.m_chroVec3[iJob]=currentParticle.populationOrg.m_chroVec3[jJob];
					currentParticle.populationOrg.m_chroVec3[jJob]=dtemp;

					int iJobIndex=find(currentParticle.population.m_chroVec3.begin(),currentParticle.population.m_chroVec3.end(),iJob+1)-currentParticle.population.m_chroVec3.begin();
					int jJobIndex=find(currentParticle.population.m_chroVec3.begin(),currentParticle.population.m_chroVec3.end(),jJob+1)-currentParticle.population.m_chroVec3.begin();
					int itemp=currentParticle.population.m_chroVec3[iJobIndex];
					currentParticle.population.m_chroVec3[iJobIndex]=currentParticle.population.m_chroVec3[jJobIndex];
					currentParticle.population.m_chroVec3[jJobIndex]=itemp;

					SolutionObj obj;
					SolutionInformation solInf;
					DecodeChromosome(currentParticle.population,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
					currentParticle.individualObj=obj;
					currentParticle.individualSolution=solInf;

					neighborhoodChroSolVec.push_back(currentParticle);
				}
			}
		}
		
	}

	vector<LSParticleInfoForSort> neighborhoodNonDominateChroSolVec;
	for (int neiIndex=0;neiIndex<neighborhoodChroSolVec.size();++neiIndex)
	{
		LSParticleInfoForSort lsp;
		lsp.individualObj=neighborhoodChroSolVec[neiIndex].individualObj;
		lsp.solutionIndex=neiIndex;
		lsp.flag=true;
		if (!count_if(neighborhoodNonDominateChroSolVec.begin(),neighborhoodNonDominateChroSolVec.end(),FindSolutionObj(lsp.individualObj)))
		{
			bool isNonDominated=true;
			int index=0;
			vector<int> deleteIndexVec;
			for (vector<LSParticleInfoForSort>::iterator sit=neighborhoodNonDominateChroSolVec.begin();sit!=neighborhoodNonDominateChroSolVec.end();++sit)
			{
				if ((sit->individualObj.m_obj1<=lsp.individualObj.m_obj1 && sit->individualObj.m_obj2<=lsp.individualObj.m_obj2 && sit->individualObj.m_obj3<=lsp.individualObj.m_obj3) && (sit->individualObj.m_obj1<lsp.individualObj.m_obj1 || sit->individualObj.m_obj2<lsp.individualObj.m_obj2 || sit->individualObj.m_obj3<lsp.individualObj.m_obj3))
				{
					isNonDominated=false;
					break;
				}
				if ((sit->individualObj.m_obj1>=lsp.individualObj.m_obj1 && sit->individualObj.m_obj2>=lsp.individualObj.m_obj2 && sit->individualObj.m_obj3>=lsp.individualObj.m_obj3) && (sit->individualObj.m_obj1>lsp.individualObj.m_obj1 || sit->individualObj.m_obj2>lsp.individualObj.m_obj2 || sit->individualObj.m_obj3>lsp.individualObj.m_obj3))
				{
					deleteIndexVec.push_back(index);
				}
				++index;
			}
			if (isNonDominated==true)
			{
				int shiftIndex=0;
				for (vector<int>::iterator dit=deleteIndexVec.begin();dit!=deleteIndexVec.end();++dit)
				{
					int dd=*dit-shiftIndex;
					neighborhoodNonDominateChroSolVec.erase(neighborhoodNonDominateChroSolVec.begin()+dd);
					++shiftIndex;
				}
				neighborhoodNonDominateChroSolVec.push_back(lsp);
			}
		}
	}

	for (int firstIndex=0;firstIndex<firstFrontChroSol.size();++firstIndex)
	{
		LSParticleInfoForSort lsp;
		lsp.individualObj=firstFrontChroSol[firstIndex].individualObj;
		lsp.solutionIndex=firstIndex;
		lsp.flag=false;
		if (!count_if(neighborhoodNonDominateChroSolVec.begin(),neighborhoodNonDominateChroSolVec.end(),FindSolutionObj(lsp.individualObj)))
		{
			bool isNonDominated=true;
			int index=0;
			vector<int> deleteIndexVec;
			for (vector<LSParticleInfoForSort>::iterator sit=neighborhoodNonDominateChroSolVec.begin();sit!=neighborhoodNonDominateChroSolVec.end();++sit)
			{
				if ((sit->individualObj.m_obj1<=lsp.individualObj.m_obj1 && sit->individualObj.m_obj2<=lsp.individualObj.m_obj2 && sit->individualObj.m_obj3<=lsp.individualObj.m_obj3) && (sit->individualObj.m_obj1<lsp.individualObj.m_obj1 || sit->individualObj.m_obj2<lsp.individualObj.m_obj2 || sit->individualObj.m_obj3<lsp.individualObj.m_obj3))
				{
					isNonDominated=false;
					break;
				}
				if ((sit->individualObj.m_obj1>=lsp.individualObj.m_obj1 && sit->individualObj.m_obj2>=lsp.individualObj.m_obj2 && sit->individualObj.m_obj3>=lsp.individualObj.m_obj3) && (sit->individualObj.m_obj1>lsp.individualObj.m_obj1 || sit->individualObj.m_obj2>lsp.individualObj.m_obj2 || sit->individualObj.m_obj3>lsp.individualObj.m_obj3))
				{
					deleteIndexVec.push_back(index);
				}
				++index;
			}
			if (isNonDominated==true)
			{
				int shiftIndex=0;
				for (vector<int>::iterator dit=deleteIndexVec.begin();dit!=deleteIndexVec.end();++dit)
				{
					int dd=*dit-shiftIndex;
					neighborhoodNonDominateChroSolVec.erase(neighborhoodNonDominateChroSolVec.begin()+dd);
					++shiftIndex;
				}
				neighborhoodNonDominateChroSolVec.push_back(lsp);
			}
		}
	}

	if (neighborhoodNonDominateChroSolVec.size()!=firstFrontChroSol.size())
	{
		if (neighborhoodNonDominateChroSolVec.size()>firstFrontChroSol.size())
		{
			
			vector<IDMultiObjValue> IdmultiObjVec;
			int indexid=0;
			for (vector<LSParticleInfoForSort>::iterator sit=neighborhoodNonDominateChroSolVec.begin();sit!=neighborhoodNonDominateChroSolVec.end();++sit)
			{
				LSParticleInfoForSort lsp=*sit;
				IDMultiObjValue ibov;
				ibov.m_layerIndexID=indexid;
				ibov.m_obj1=lsp.individualObj.m_obj1;
				ibov.m_obj2=lsp.individualObj.m_obj2;
				ibov.m_obj3=lsp.individualObj.m_obj3;
				IdmultiObjVec.push_back(ibov);
				++indexid;
			}

			sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj1Short);
			for (int i=0;i<IdmultiObjVec.size();++i)
			{
				if (i==0)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else if (i==IdmultiObjVec.size()-1)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else
				{
					double sub=IdmultiObjVec[i+1].m_obj1-IdmultiObjVec[i-1].m_obj1;
					double maxminsub=IdmultiObjVec.back().m_obj1-IdmultiObjVec.front().m_obj1;
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=sub/maxminsub;
				}
			}
			sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj2Short);
			for (int i=0;i<IdmultiObjVec.size();++i)
			{
				if (i==0)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else if (i==IdmultiObjVec.size()-1)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else
				{
					double sub=IdmultiObjVec[i+1].m_obj2-IdmultiObjVec[i-1].m_obj2;
					double maxminsub=IdmultiObjVec.back().m_obj2-IdmultiObjVec.front().m_obj2;
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=sub/maxminsub;
				}
			}
			sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj3Short);
			for (int i=0;i<IdmultiObjVec.size();++i)
			{
				if (i==0)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else if (i==IdmultiObjVec.size()-1)
				{
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=1;
				}
				else
				{
					double sub=IdmultiObjVec[i+1].m_obj3-IdmultiObjVec[i-1].m_obj3;
					double maxminsub=IdmultiObjVec.back().m_obj3-IdmultiObjVec.front().m_obj3;
					neighborhoodNonDominateChroSolVec[IdmultiObjVec[i].m_layerIndexID].cdDistance+=sub/maxminsub;
				}
			}

			sort(neighborhoodNonDominateChroSolVec.begin(),neighborhoodNonDominateChroSolVec.end(),IsCDShort);
			neighborhoodNonDominateChroSolVec.erase(neighborhoodNonDominateChroSolVec.begin()+firstFrontChroSol.size(),neighborhoodNonDominateChroSolVec.end());
		}
	}
	vector<LSParticleInfo> firstFrontChroSoltemp=firstFrontChroSol;
	for (int i=0;i<neighborhoodNonDominateChroSolVec.size();++i)
	{
		LSParticleInfo lsp;
		if (neighborhoodNonDominateChroSolVec[i].flag==true)
		{
			lsp=neighborhoodChroSolVec[neighborhoodNonDominateChroSolVec[i].solutionIndex];
		}
		else
		{
			lsp=firstFrontChroSoltemp[neighborhoodNonDominateChroSolVec[i].solutionIndex];
		}
		firstFrontChroSol[i]=lsp;
	}
	improvedFrontChroSol=firstFrontChroSol;
	firstFrontChroSol=firstFrontChroSoltemp;
	
}
void ImproveParticle(ChromosomeOrg &chromOrg,Chromosome &chrom,SolutionObj &sobj,SolutionInformation &solInf,vector<CustomerData> &customerDataVec)
{
	//Proposition 4
	bool firstFlag=true;
	int reverseIndex=chrom.m_chroVec1.size()-1;
	if (solInf.LastProcessingJob.size()<=1)
	{
		return;
	}
	for (vector<int>::reverse_iterator rit=solInf.LastProcessingJob.rbegin();rit!=solInf.LastProcessingJob.rend();++rit)
	{
		int vechicleID=chrom.m_chroVec2[*rit-1];
		double departureTime=solInf.vechicleDepartTime[vechicleID];
		double completeTime=solInf.jobCompleteTime[*rit];

		if (firstFlag==true)
		{
			firstFlag=false;
			if (departureTime>completeTime)
			{
				double postponedTime=departureTime-completeTime;
				int previousJob=*(rit+1);
				double reducedHoldCost=0;
				while (chrom.m_chroVec1[reverseIndex]!=previousJob)
				{
					int currentJob=chrom.m_chroVec1[reverseIndex];
					solInf.jobCompleteTime[currentJob]+=postponedTime;
					reducedHoldCost+=customerDataVec[currentJob-1].m_unitHoldingCost*postponedTime;
					--reverseIndex;
				}
				vector<int>::reverse_iterator lrit=rit+1;
				int lasVecID=chrom.m_chroVec2[*lrit-1];
				chrom.m_chroVec4[lasVecID-1]+=postponedTime;
				chrom.m_chroVec5[vechicleID-1]-=postponedTime;
				sobj.m_obj1-=reducedHoldCost;
			}
		}
		else
		{
			double idleTime=chrom.m_chroVec4[vechicleID-1];
			if (departureTime>completeTime)
			{
				
				double postponedTime=0;
				if (departureTime>completeTime+idleTime)
				{
					postponedTime=idleTime;
				}
				else
				{
					postponedTime=departureTime-completeTime;
				}

				double reducedHoldCost=0;
				if (rit==solInf.LastProcessingJob.rend()-1)
				{
					while (reverseIndex>=0)
					{
						int currentJob=chrom.m_chroVec1[reverseIndex];
						solInf.jobCompleteTime[currentJob]+=postponedTime;
						reducedHoldCost+=customerDataVec[currentJob-1].m_unitHoldingCost*postponedTime;
						--reverseIndex;
					}
					chrom.m_chroVec4[vechicleID-1]-=postponedTime;
					int lastVecID=chrom.m_chroVec2[chrom.m_chroVec1.back()-1];
					chrom.m_chroVec4[lastVecID-1]+=postponedTime;
					chrom.m_chroVec5[vechicleID-1]-=postponedTime;
					sobj.m_obj1-=reducedHoldCost;
				} 
				else
				{
					int previousJob=*(rit+1);
					while (chrom.m_chroVec1[reverseIndex]!=previousJob)
					{
						int currentJob=chrom.m_chroVec1[reverseIndex];
						solInf.jobCompleteTime[currentJob]+=postponedTime;
						reducedHoldCost+=customerDataVec[currentJob-1].m_unitHoldingCost*postponedTime;
						--reverseIndex;
					}
					chrom.m_chroVec4[vechicleID-1]-=postponedTime;
					int previousVechicleID=chrom.m_chroVec2[*(rit+1)-1];
					chrom.m_chroVec4[previousVechicleID-1]+=postponedTime;
					chrom.m_chroVec5[vechicleID-1]-=postponedTime;
					sobj.m_obj1-=reducedHoldCost;
				}
				
			}
		}
	}

	//Proposition 6
	double reducedHoldCost=0;
	vector<int> processingSequence=chrom.m_chroVec1;
	vector<double> processingSequenceOrg=chromOrg.m_chroVec1;
	for (int i=0;i<processingSequence.size()-1;++i)
	{
		int j=i+1;

		int iVid=chrom.m_chroVec2[processingSequence[i]-1];
		int jVid=chrom.m_chroVec2[processingSequence[j]-1];
		if (iVid==jVid)
		{
			double aipj=customerDataVec[processingSequence[i]-1].m_unitHoldingCost*customerDataVec[processingSequence[j]-1].m_processingTime;
			double ajpi=customerDataVec[processingSequence[j]-1].m_unitHoldingCost*customerDataVec[processingSequence[i]-1].m_processingTime;
			if (aipj>ajpi)
			{
				double startTime=solInf.jobCompleteTime[processingSequence[i]]-customerDataVec[processingSequence[i]-1].m_processingTime;
				double orgIProcessingTime=customerDataVec[processingSequence[i]-1].m_processingTime;
				double orgJprocessingTime=customerDataVec[processingSequence[j]-1].m_processingTime;
				int jobI=processingSequence[i];
				int jobJ=processingSequence[j];
				int temp=processingSequence[i];
				processingSequence[i]=processingSequence[j];
				processingSequence[j]=temp;
				double tempOrg=processingSequenceOrg[i];
				processingSequenceOrg[i]=processingSequenceOrg[j];
				processingSequenceOrg[j]=tempOrg;
				reducedHoldCost+=aipj-ajpi;
				solInf.jobCompleteTime[jobJ]=startTime+orgJprocessingTime;
				solInf.jobCompleteTime[jobI]=solInf.jobCompleteTime[jobJ]+orgIProcessingTime;
				ReverseChangeTwoJobs(i,processingSequence,processingSequenceOrg,reducedHoldCost,solInf,customerDataVec,chrom);
			}
		}
	}
	sobj.m_obj1-=reducedHoldCost;
	chrom.m_chroVec1=processingSequence;
	chromOrg.m_chroVec1=processingSequenceOrg;

	//Proposition 7
	for (vector<pair<int,double>>::iterator vit=solInf.allJobTardyVec.begin();vit!=solInf.allJobTardyVec.end();++vit)
	{
		double departureIdleTime=chrom.m_chroVec5[vit->first-1];
		if (departureIdleTime>0.001)
		{
			double advancedTime;
			if (departureIdleTime<vit->second)
			{
				advancedTime=departureIdleTime;
			}
			else
			{
				advancedTime=vit->second;
			}
			chrom.m_chroVec5[vit->first-1]-=advancedTime;
			double decreasedHoldCost=0;
			for (int job=0;job<chrom.m_chroVec2.size();++job)
			{
				if (chrom.m_chroVec2[job]==vit->first)
				{
					decreasedHoldCost+=customerDataVec[job].m_unitHoldingCost*advancedTime;
				}
			}
			sobj.m_obj1-=decreasedHoldCost;
		}
	}

	return;
}

int _tmain(int argc, _TCHAR* argv[])
{
	
	srand(time(0));
	
	string fileNameShort;
	for (int ci = 1; ci <= 22; ++ci)//max 22
	{
		for (int repeat = 1; repeat <= 5; ++repeat)//max 5
		{
			if (ci == 1)
			{
				fileNameShort = "A-n32-k5";
			}
			else if (ci == 2)
			{
				fileNameShort = "A-n37-k6";
			}
			else if (ci == 3)
			{
				fileNameShort = "A-n44-k6";
			}
			else if (ci == 4)
			{
				fileNameShort = "A-n48-k7";
			}
			else if (ci == 5)
			{
				fileNameShort = "A-n53-k7";
			}
			else if (ci == 6)
			{
				fileNameShort = "A-n60-k9";
			}
			else if (ci == 7)
			{
				fileNameShort = "A-n65-k9";
			}
			else if (ci == 8)
			{
				fileNameShort = "A-n69-k9";
			}
			else if (ci == 9)
			{
				fileNameShort = "A-n80-k10";
			}
			else if (ci == 10)
			{
				fileNameShort = "B-n39-k5";
			}
			else if (ci == 11)
			{
				fileNameShort = "B-n41-k6";
			}
			else if (ci == 12)
			{
				fileNameShort = "B-n50-k7";
			}
			else if (ci == 13)
			{
				fileNameShort = "B-n56-k7";
			}
			else if (ci == 14)
			{
				fileNameShort = "B-n63-k10";
			}
			else if (ci == 15)
			{
				fileNameShort = "B-n78-k10";
			}
			else if (ci == 16)
			{
				fileNameShort = "E-n23-k3";
			}
			else if (ci == 17)
			{
				fileNameShort = "E-n33-k4";
			}
			else if (ci == 18)
			{
				fileNameShort = "E-n51-k5";
			}
			else if (ci == 19)
			{
				fileNameShort = "E-n76-k10";
			}
			else if (ci == 20)
			{
				fileNameShort = "E-n76-k14";
			}
			else if (ci == 21)
			{
				fileNameShort = "M-n101-k10";
			}
			else if (ci == 22)
			{
				fileNameShort = "M-n121-k7";
			}


			//read Data
			int vehicleNum;
			double vehicleLoad;
			DepotData depot;
			vector<CustomerData> customerDataVec;
			stringstream ss;
			ss<<repeat;
			string inputFileName=fileNameShort+"_"+ss.str()+"_revised.txt";
			bool isDataOK=ReadData(vehicleNum,vehicleLoad,depot,customerDataVec,inputFileName);
			if (isDataOK==false)
			{
				cout<<"DATA IS NOT OK!";
				return false;
			}
			int customerNum=customerDataVec.size();

			//Calculate distance
			map<pair<int,int>,double> distanceMap;
			Caldistance(distanceMap,depot,customerDataVec);

			//Parameter setting
			clock_t begTime;
			begTime=clock();
			int popSize=1000;
			double fi=0.4;
			//int totalStep=150;
			double runTime=8*customerNum*vehicleNum;
			Coefficient modelCoeff;
			modelCoeff.hiring_vehicle=20;
			modelCoeff.infeasibleCoff=4;
			

			//Swarm initialization 
			vector<ChromosomeOrg> populationOrg;
			vector<Chromosome> population;
			vector<ChromosomeVelocity> populationVelocity;
			vector<SolutionObj> individualObj;
			vector<SolutionInformation> individualSolution;
			PopIni(population,populationVelocity,vehicleNum,customerNum,popSize,vehicleLoad,customerDataVec,distanceMap);
			ChangeFromPopOrg(population,populationOrg);

			//Calculate objective values for each particle
			for (vector<Chromosome>::iterator pit=population.begin();pit!=population.end();++pit)
			{
				SolutionObj obj;
				SolutionInformation solInf;
				DecodeChromosome(*pit,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
				individualObj.push_back(obj);
				individualSolution.push_back(solInf);
			}

			//Particle quality enhancement
			for (int indIndex=0;indIndex<population.size();++indIndex)
			{
				ImproveParticle(populationOrg[indIndex],population[indIndex],individualObj[indIndex],individualSolution[indIndex],customerDataVec);
				//test
				Chromosome chromTest=population[indIndex];
				SolutionObj sobjTest;
				SolutionInformation solInfTest;
				DecodeChromosome(chromTest,sobjTest,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInfTest);
				individualObj[indIndex]=sobjTest;
				individualSolution[indIndex]=solInfTest;
				//test
			}

			//Iteration
			clock_t endTime;
			vector<Chromosome> ArPopulation;
			vector<SolutionObj> ArindividualObj;
			while (true)
			{
				endTime=clock();
				if ((endTime-begTime)/CLOCKS_PER_SEC > runTime)
				{
					break;
				}
				//non-dominated sorting
				vector<int> np;
				vector<vector<int>> sp;
				vector<int> emptyVec;
				for (int i=0;i<individualObj.size();++i)
				{
					np.push_back(0);
					sp.push_back(emptyVec);
				}

				for (int i=0;i<individualObj.size();++i)
				{
					for (int j=i+1;j<individualObj.size();++j)
					{
						if ((individualObj[i].m_obj1<=individualObj[j].m_obj1 && individualObj[i].m_obj2<=individualObj[j].m_obj2 && individualObj[i].m_obj3<=individualObj[j].m_obj3) && (individualObj[i].m_obj1<individualObj[j].m_obj1 || individualObj[i].m_obj2<individualObj[j].m_obj2 || individualObj[i].m_obj3<individualObj[j].m_obj3))
						{
							sp[i].push_back(j);
							++np[j];
						}
						else if ((individualObj[i].m_obj1>=individualObj[j].m_obj1 && individualObj[i].m_obj2>=individualObj[j].m_obj2 && individualObj[i].m_obj3>=individualObj[j].m_obj3) && (individualObj[i].m_obj1>individualObj[j].m_obj1 || individualObj[i].m_obj2>individualObj[j].m_obj2 || individualObj[i].m_obj3>individualObj[j].m_obj3))
						{
							sp[j].push_back(i);
							++np[i];
						}
					}
				}

				int layerNum=1;
				int nonSortSolutionNum=individualObj.size();
				set<int> alreadySortSolution;
				map<int,vector<int>> allLayerSolution;
				while (nonSortSolutionNum>0)
				{
					vector<int> layerSolution;
					for (int i=0;i<np.size();++i)
					{
						if (np[i]==0 && !alreadySortSolution.count(i))
						{
							layerSolution.push_back(i);
							alreadySortSolution.insert(i);
							--nonSortSolutionNum;
						}
					}
					if (!layerSolution.empty())
					{
						allLayerSolution.insert(make_pair(layerNum,layerSolution));
						++layerNum;
						for (vector<int>::iterator it=layerSolution.begin();it!=layerSolution.end();++it)
						{
							for (vector<int>::iterator it2=sp[*it].begin();it2!=sp[*it].end();++it2)
							{
								--np[*it2];
							}
						}
					}
				}

				//Crowding distance calculation
				map<int,vector<double>> allLayerDistance;
				for (map<int,vector<int>>::iterator mit=allLayerSolution.begin();mit!=allLayerSolution.end();++mit)
				{
					vector<IDMultiObjValue> IdmultiObjVec;
					int indexid=0;
					for (vector<int>::iterator sit=mit->second.begin();sit!=mit->second.end();++sit)
					{
						IDMultiObjValue ibov;
						ibov.m_layerIndexID=indexid;
						ibov.m_obj1=individualObj[*sit].m_obj1;
						ibov.m_obj2=individualObj[*sit].m_obj2;
						ibov.m_obj3=individualObj[*sit].m_obj3;
						IdmultiObjVec.push_back(ibov);
						++indexid;
					}
					vector<double> Idistance(mit->second.size(),0.0);

					sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj1Short);
					for (int i=0;i<IdmultiObjVec.size();++i)
					{
						if (i==0)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else if (i==IdmultiObjVec.size()-1)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else
						{
							double sub=IdmultiObjVec[i+1].m_obj1-IdmultiObjVec[i-1].m_obj1;
							double maxminsub=IdmultiObjVec.back().m_obj1-IdmultiObjVec.front().m_obj1;
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=sub/maxminsub;
						}
					}
					sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj2Short);
					for (int i=0;i<IdmultiObjVec.size();++i)
					{
						if (i==0)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else if (i==IdmultiObjVec.size()-1)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else
						{
							double sub=IdmultiObjVec[i+1].m_obj2-IdmultiObjVec[i-1].m_obj2;
							double maxminsub=IdmultiObjVec.back().m_obj2-IdmultiObjVec.front().m_obj2;
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=sub/maxminsub;
						}
					}
					sort(IdmultiObjVec.begin(),IdmultiObjVec.end(),IsObj3Short);
					for (int i=0;i<IdmultiObjVec.size();++i)
					{
						if (i==0)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else if (i==IdmultiObjVec.size()-1)
						{
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=1;
						}
						else
						{
							double sub=IdmultiObjVec[i+1].m_obj3-IdmultiObjVec[i-1].m_obj3;
							double maxminsub=IdmultiObjVec.back().m_obj3-IdmultiObjVec.front().m_obj3;
							Idistance[IdmultiObjVec[i].m_layerIndexID]+=sub/maxminsub;
						}
					}
					//
					allLayerDistance.insert(make_pair(mit->first,Idistance));
				}
				//update non-dominated solutions
				for (vector<int>::iterator it=allLayerSolution[1].begin();it!=allLayerSolution[1].end();++it)
				{
					if (count_if(ArindividualObj.begin(),ArindividualObj.end(),FindSolutionObj2(individualObj[*it])))
					{
						continue;
					}
					bool isNonDominated=true;
					int index=0;
					vector<int> deleteIndexVec;
					for (vector<SolutionObj>::iterator sit=ArindividualObj.begin();sit!=ArindividualObj.end();++sit)
					{
						if ((sit->m_obj1<=individualObj[*it].m_obj1 && sit->m_obj2<=individualObj[*it].m_obj2 && sit->m_obj3<=individualObj[*it].m_obj3) && (sit->m_obj1<individualObj[*it].m_obj1 || sit->m_obj2<individualObj[*it].m_obj2 || sit->m_obj3<individualObj[*it].m_obj3))
						{
							isNonDominated=false;
							break;
						}
						if ((sit->m_obj1>=individualObj[*it].m_obj1 && sit->m_obj2>=individualObj[*it].m_obj2 && sit->m_obj3>=individualObj[*it].m_obj3) && (sit->m_obj1>individualObj[*it].m_obj1 || sit->m_obj2>individualObj[*it].m_obj2 || sit->m_obj3>individualObj[*it].m_obj3))
						{
							deleteIndexVec.push_back(index);
						}
						++index;
					}
					if (isNonDominated==true)
					{
						int shiftIndex=0;
						for (vector<int>::iterator dit=deleteIndexVec.begin();dit!=deleteIndexVec.end();++dit)
						{
							int dd=*dit-shiftIndex;
							ArindividualObj.erase(ArindividualObj.begin()+dd);
							ArPopulation.erase(ArPopulation.begin()+dd);
							++shiftIndex;
						}
						ArindividualObj.push_back(individualObj[*it]);
						ArPopulation.push_back(population[*it]);
					}
				}

				//Particle update process
				int RnumofLayers=allLayerSolution.size();
				if (RnumofLayers>=2)
				{
					for (int r=RnumofLayers;r>=3;--r)
					{
						for (vector<int>::iterator vit=allLayerSolution[r].begin();vit!=allLayerSolution[r].end();++vit)
						{
							int r2=2+rand()%(r-2);
							int r1=1+rand()%(r2-1);
							int r1size=allLayerSolution[r1].size()-1;
							int r2size=allLayerSolution[r2].size()-1;
							int r1RandomIndex=rand()%(r1size+1);
							int r2RandomIndex=rand()%(r2size+1);
							int r1SolutionID=allLayerSolution[r1][r1RandomIndex];
							int r2SolutionID=allLayerSolution[r2][r2RandomIndex];
							ChromosomeOrg particleOrgR1=populationOrg[r1SolutionID];
							ChromosomeOrg particleOrgR2=populationOrg[r2SolutionID];
							ChromosomeVelocity velocityR1=populationVelocity[r1SolutionID];
							ChromosomeVelocity velocityR2=populationVelocity[r2SolutionID];

							double lamda1=(rand()%101)/100.0;
							double lamda2=(rand()%101)/100.0;
							double lamda3=(rand()%101)/100.0;
							ChromosomeOrg particleOrgR=populationOrg[*vit];
							ChromosomeVelocity velocityR=populationVelocity[*vit];
							for (int vindex=0;vindex<velocityR.m_VelchroVec1.size();++vindex)
							{
								velocityR.m_VelchroVec1[vindex]=lamda1*velocityR.m_VelchroVec1[vindex]+lamda2*(particleOrgR1.m_chroVec1[vindex]-particleOrgR.m_chroVec1[vindex])+fi*lamda3*(particleOrgR2.m_chroVec1[vindex]-particleOrgR.m_chroVec1[vindex]);
								particleOrgR.m_chroVec1[vindex]=particleOrgR.m_chroVec1[vindex]+velocityR.m_VelchroVec1[vindex];
								velocityR.m_VelchroVec2[vindex]=lamda1*velocityR.m_VelchroVec2[vindex]+lamda2*(particleOrgR1.m_chroVec2[vindex]-particleOrgR.m_chroVec2[vindex])+fi*lamda3*(particleOrgR2.m_chroVec2[vindex]-particleOrgR.m_chroVec2[vindex]);
								particleOrgR.m_chroVec2[vindex]=particleOrgR.m_chroVec2[vindex]+velocityR.m_VelchroVec2[vindex];
								velocityR.m_VelchroVec3[vindex]=lamda1*velocityR.m_VelchroVec3[vindex]+lamda2*(particleOrgR1.m_chroVec3[vindex]-particleOrgR.m_chroVec3[vindex])+fi*lamda3*(particleOrgR2.m_chroVec3[vindex]-particleOrgR.m_chroVec3[vindex]);
								particleOrgR.m_chroVec3[vindex]=particleOrgR.m_chroVec3[vindex]+velocityR.m_VelchroVec3[vindex];
							}
							for (int vindex=0;vindex<velocityR.m_VelchroVec4.size();++vindex)
							{
								velocityR.m_VelchroVec4[vindex]=lamda1*velocityR.m_VelchroVec4[vindex]+lamda2*(particleOrgR1.m_chroVec4[vindex]-particleOrgR.m_chroVec4[vindex])+fi*lamda3*(particleOrgR2.m_chroVec4[vindex]-particleOrgR.m_chroVec4[vindex]);
								particleOrgR.m_chroVec4[vindex]=particleOrgR.m_chroVec4[vindex]+velocityR.m_VelchroVec4[vindex];
								velocityR.m_VelchroVec5[vindex]=lamda1*velocityR.m_VelchroVec5[vindex]+lamda2*(particleOrgR1.m_chroVec5[vindex]-particleOrgR.m_chroVec5[vindex])+fi*lamda3*(particleOrgR2.m_chroVec5[vindex]-particleOrgR.m_chroVec5[vindex]);
								particleOrgR.m_chroVec5[vindex]=particleOrgR.m_chroVec5[vindex]+velocityR.m_VelchroVec5[vindex];
							}
							
							Chromosome updateCharom;
							ChangeFromPop(updateCharom,particleOrgR,vehicleNum);
							
							SolutionObj obj;
							SolutionInformation solInf;
							DecodeChromosome(updateCharom,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
							
							ImproveParticle(particleOrgR,updateCharom,obj,solInf,customerDataVec);
							//test
							Chromosome chromTest=updateCharom;
							SolutionObj sobjTest;
							SolutionInformation solInfTest;
							DecodeChromosome(chromTest,sobjTest,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInfTest);
							//test
							
							population[*vit]=updateCharom;
							populationOrg[*vit]=particleOrgR;
							populationVelocity[*vit]=velocityR;
							individualObj[*vit]=sobjTest;
							individualSolution[*vit]=solInfTest;
						}
					}
					
					for (vector<int>::iterator vit=allLayerSolution[2].begin();vit!=allLayerSolution[2].end();++vit)
					{
						
						int levelsize=allLayerSolution[1].size()-1;
						int r1RandomIndex=rand()%levelsize;
						int r2RandomIndex=r1RandomIndex+1+rand()%(levelsize-r1RandomIndex);
						int r1SolutionID=allLayerSolution[1][r1RandomIndex];
						int r2SolutionID=allLayerSolution[1][r2RandomIndex];
						ChromosomeOrg particleOrgR1=populationOrg[r1SolutionID];
						ChromosomeOrg particleOrgR2=populationOrg[r2SolutionID];
						ChromosomeVelocity velocityR1=populationVelocity[r1SolutionID];
						ChromosomeVelocity velocityR2=populationVelocity[r2SolutionID];
						
						double lamda1=(rand()%101)/100.0;
						double lamda2=(rand()%101)/100.0;
						double lamda3=(rand()%101)/100.0;
						ChromosomeOrg particleOrgR=populationOrg[*vit];
						ChromosomeVelocity velocityR=populationVelocity[*vit];
						for (int vindex=0;vindex<velocityR.m_VelchroVec1.size();++vindex)
						{
							velocityR.m_VelchroVec1[vindex]=lamda1*velocityR.m_VelchroVec1[vindex]+lamda2*(particleOrgR1.m_chroVec1[vindex]-particleOrgR.m_chroVec1[vindex])+fi*lamda3*(particleOrgR2.m_chroVec1[vindex]-particleOrgR.m_chroVec1[vindex]);
							particleOrgR.m_chroVec1[vindex]=particleOrgR.m_chroVec1[vindex]+velocityR.m_VelchroVec1[vindex];
							velocityR.m_VelchroVec2[vindex]=lamda1*velocityR.m_VelchroVec2[vindex]+lamda2*(particleOrgR1.m_chroVec2[vindex]-particleOrgR.m_chroVec2[vindex])+fi*lamda3*(particleOrgR2.m_chroVec2[vindex]-particleOrgR.m_chroVec2[vindex]);
							particleOrgR.m_chroVec2[vindex]=particleOrgR.m_chroVec2[vindex]+velocityR.m_VelchroVec2[vindex];
							velocityR.m_VelchroVec3[vindex]=lamda1*velocityR.m_VelchroVec3[vindex]+lamda2*(particleOrgR1.m_chroVec3[vindex]-particleOrgR.m_chroVec3[vindex])+fi*lamda3*(particleOrgR2.m_chroVec3[vindex]-particleOrgR.m_chroVec3[vindex]);
							particleOrgR.m_chroVec3[vindex]=particleOrgR.m_chroVec3[vindex]+velocityR.m_VelchroVec3[vindex];
						}
						for (int vindex=0;vindex<velocityR.m_VelchroVec4.size();++vindex)
						{
							velocityR.m_VelchroVec4[vindex]=lamda1*velocityR.m_VelchroVec4[vindex]+lamda2*(particleOrgR1.m_chroVec4[vindex]-particleOrgR.m_chroVec4[vindex])+fi*lamda3*(particleOrgR2.m_chroVec4[vindex]-particleOrgR.m_chroVec4[vindex]);
							particleOrgR.m_chroVec4[vindex]=particleOrgR.m_chroVec4[vindex]+velocityR.m_VelchroVec4[vindex];
							velocityR.m_VelchroVec5[vindex]=lamda1*velocityR.m_VelchroVec5[vindex]+lamda2*(particleOrgR1.m_chroVec5[vindex]-particleOrgR.m_chroVec5[vindex])+fi*lamda3*(particleOrgR2.m_chroVec5[vindex]-particleOrgR.m_chroVec5[vindex]);
							particleOrgR.m_chroVec5[vindex]=particleOrgR.m_chroVec5[vindex]+velocityR.m_VelchroVec5[vindex];
						}
						
						Chromosome updateCharom;
						ChangeFromPop(updateCharom,particleOrgR,vehicleNum);
						
						SolutionObj obj;
						SolutionInformation solInf;
						DecodeChromosome(updateCharom,obj,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInf);
						
						ImproveParticle(particleOrgR,updateCharom,obj,solInf,customerDataVec);
						//test
						Chromosome chromTest=updateCharom;
						SolutionObj sobjTest;
						SolutionInformation solInfTest;
						DecodeChromosome(chromTest,sobjTest,customerDataVec,distanceMap,vehicleLoad,modelCoeff,solInfTest);
						//test
						
						population[*vit]=updateCharom;
						populationOrg[*vit]=particleOrgR;
						populationVelocity[*vit]=velocityR;
						individualObj[*vit]=sobjTest;
						individualSolution[*vit]=solInfTest;
					}
				} 

				//Local search
				vector<LSParticleInfo> firstFrontChroSol;
				for (vector<int>::iterator vit=allLayerSolution[1].begin();vit!=allLayerSolution[1].end();++vit)
				{
					LSParticleInfo lsp;
					lsp.population=population[*vit];
					lsp.populationOrg=populationOrg[*vit];
					lsp.populationVelocity=populationVelocity[*vit];
					lsp.individualObj=individualObj[*vit];
					lsp.individualSolution=individualSolution[*vit];
					firstFrontChroSol.push_back(lsp);
				}
				vector<LSParticleInfo> improvedFrontChroSol;

				NondominatedLocalSearch(firstFrontChroSol,improvedFrontChroSol,3,5,customerDataVec,vehicleLoad,vehicleNum,distanceMap,modelCoeff);

				for (int findex=0;findex<allLayerSolution[1].size();++findex)
				{
					population[allLayerSolution[1][findex]]=improvedFrontChroSol[findex].population;
					populationOrg[allLayerSolution[1][findex]]=improvedFrontChroSol[findex].populationOrg;
					populationVelocity[allLayerSolution[1][findex]]=improvedFrontChroSol[findex].populationVelocity;
					individualObj[allLayerSolution[1][findex]]=improvedFrontChroSol[findex].individualObj;
					individualSolution[allLayerSolution[1][findex]]=improvedFrontChroSol[findex].individualSolution;
				}

				static bool firstFlag=true;
				if (firstFlag)
				{
					cout<<"The current non-dominated solution set of "<<fileNameShort<<"_"<<repeat<<": "<<endl;
					firstFlag=false;
				}
				else
				{
					cout<<endl<<"The current non-dominated solution set of "<<fileNameShort<<"_"<<repeat<<": "<<endl;
				}
				
				int solutionID=1;
				for (vector<SolutionObj>::iterator it=ArindividualObj.begin();it!=ArindividualObj.end();++it)
				{
					cout<<"Solution"<<solutionID<<": ";
					if(it->m_feasible==1)
					{
						cout<<"feasible"<<" "<<it->m_obj1<<" "<<it->m_obj2<<" "<<it->m_obj3<<endl;
					}
					else
					{
						cout<<"infeasible"<<" "<<it->m_obj1<<" "<<it->m_obj2<<" "<<it->m_obj3<<endl;
					}
					++solutionID;
				}
			}

		}
	}

	return 0;
}

